/* place holder for dynamically updated js */
function update_details() {
}
