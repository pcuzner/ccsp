function update_mode() {
}